USE [MyPatientDB]
GO

/****** Object:  Table [dbo].[t_PatientInfo]    Script Date: 12/15/2021 06:12:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[t_PatientInfo](
	[PatientID] [int] IDENTITY(1,1) NOT NULL,
	[PatientName] [varchar](50) NULL,
	[PatientDOB] [date] NULL,
	[Gender] [nchar](10) NULL,
	[PostalCode] [nchar](10) NULL,
	[City] [nchar](10) NULL,
	[Ward] [nchar](10) NULL,
	[Bed] [nchar](10) NULL,
	[Unit] [nchar](10) NULL,
	[AdmissionDate] [datetime] NULL,
	[DischargeDate] [datetime] NULL,
	[Treatingdoctor] [varchar](50) NULL,
 CONSTRAINT [PK_t_PatientInfo] PRIMARY KEY CLUSTERED 
(
	[PatientID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

