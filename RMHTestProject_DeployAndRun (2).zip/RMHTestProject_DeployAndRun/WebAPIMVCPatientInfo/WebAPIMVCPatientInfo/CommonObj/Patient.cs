﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAPIMVCPatientInfo.CommonObj
{
    public class Patient
    {
        private int nPatientID = 0;
        private string strPatientName = string.Empty;
        private string strPostCode = string.Empty;

        public int PatientID
        {
            get { return this.nPatientID; }
            set { this.nPatientID = value; }
        }

        public string PatientName
        {
            get { return this.strPatientName; }
            set { this.strPatientName = value; }
        }
        public string PostCode
        {
            get { return this.strPostCode; }
            set { this.strPostCode = value; }
        }
    }
}