﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using PatientDataAccess;

namespace WebAPIMVCPatientInfo.Controllers
{
    
    
    public class PatientInfoController : ApiController
    {
        List<CommonObj.Patient> objPatientInfo;
        // GET api/patientinfo
        public IEnumerable<t_PatientInfo> Get()
        {
        //    return new string[] { "10", "First and Kast Name 10", "01/01/1975" };
            using (PatientDataAccess.MyPatientDBEntities entities = new PatientDataAccess.MyPatientDBEntities())
            {
                return entities.t_PatientInfo.ToList();
            }
        }
       
        //public static List<CommonObj.Patient> PatientList = new List<CommonObj.Patient>()  
        //{  
        //    new CommonObj.Patient { PatientID = 1, PatientName="First and Last Name 10", PostCode="12234"},  
        //    new CommonObj.Patient { PatientID = 2, PatientName="First and Last Name 20", PostCode="1234"},  
        //    new CommonObj.Patient { PatientID = 3, PatientName="First and Last Name 30", PostCode="4567"},  
        //};

        //// GET api/default1
        //public List<CommonObj.Patient> Get()
        //{
        //    return PatientList;  
        //}

        //// GET api/patientinfo/5
        //public CommonObj.Patient Get(int id)
        //{

        //    CommonObj.Patient objPatientInfo = (from patient in PatientList
        //                                        where patient.PatientID == patient.PatientID
        //                                        select patient).SingleOrDefault();
        //    return objPatientInfo;
        //}

        // POST api/patientinfo
        public List<CommonObj.Patient> Post(CommonObj.Patient ObjPatientInfo)
        {
            objPatientInfo.Add(ObjPatientInfo);

            return objPatientInfo;
        }  

        //// PUT api/patientinfo/5
        //public void Put(int id, [FromBody]string value)
        //{
        //}

        //// DELETE api/patientinfo/5
        public void Delete(int id)
        {
            objPatientInfo.RemoveAll(temp => temp.PatientID == id);
        }  
        //or
        //[Route("api/DeletePatient")]
        [HttpPost]
        public t_PatientInfo DeletePatient(t_PatientInfo objPatientInfo)
        {
        using (PatientDataAccess.MyPatientDBEntities entities = new PatientDataAccess.MyPatientDBEntities())
        {
             objPatientInfo = (from c in entities.t_PatientInfo
                                 where c.PatientID == objPatientInfo.PatientID 
                                 select c).FirstOrDefault();
            if (objPatientInfo != null)
            {
                entities.t_PatientInfo.Remove(objPatientInfo);
                entities.SaveChanges();
                return objPatientInfo;
            }
        }
 
        return null;
    }
}
    }

