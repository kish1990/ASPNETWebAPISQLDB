USE [MyPatientDB]
GO

/****** Object:  StoredProcedure [dbo].[AddPatientInfo]    Script Date: 12/15/2021 00:52:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Kishor Oswal>
-- Create date: <12-14-2021>
-- Description:	<Add New Patient>
-- =============================================
CREATE PROCEDURE [dbo].[AddPatientInfo]
	-- Add the parameters for the stored procedure here
	@PatientName varchar(50),
	@PatientDOB Date,
    @Gender nchar(10),
    @City nchar(10),
    @Ward nchar(10),
    @Bed nchar(10),
    @Unit nchar(10),
    @PostalCode nchar(10),
    @AdmissionDate Date,
    @DischargeDate Date,
    @Treatingdoctor varchar(50),
    
    @PatientID int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	INSERT INTO t_PatientInfo
    (PatientName,PatientDOB,Gender,City,PostalCode,Ward,Bed,Unit,AdmissionDate,
     DischargeDate,Treatingdoctor)
    Values (@PatientName,@PatientDOB,@Gender, @City, @PostalCode,@Ward,@Bed,@Unit,@AdmissionDate
    ,@DischargeDate,@Treatingdoctor)
 SET @PatientID = SCOPE_IDENTITY()
 
 
 RETURN @PatientID
	
END





GO

