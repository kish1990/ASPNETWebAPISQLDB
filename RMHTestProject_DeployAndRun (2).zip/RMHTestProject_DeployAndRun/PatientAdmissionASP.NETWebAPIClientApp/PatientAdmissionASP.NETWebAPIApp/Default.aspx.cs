﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PatientAdmissionASPNETWebAPIApp
{
    public partial class _Default : Page
    {
        DAL.UserData objUserData = new DAL.UserData();
        List<CommonObj.Users> objUsers;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            TextBox tbox = this.FindControl("txtUser") as TextBox;
            if (tbox != null)
            {
                ScriptManager.GetCurrent(this.Page).SetFocus(tbox);
            }
            txtUser.Focus();
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                Session["UserName"] = "";
                objUsers = objUserData.GetUser(txtUser.Text.ToLower().Trim(), txtPwd.Text.Trim());
                if (objUsers.Count > 0)
                {
                    if (objUsers[0].UserName.ToLower().Trim() == txtUser.Text.ToLower().Trim() && objUsers[0].Password.ToLower().Trim() == txtPwd.Text.ToLower().Trim())
                    {

                       
                        Session["UserName"] = objUsers[0].UserName;
                       
                        Response.Redirect("Home.aspx");
                    }
                    else
                    {
                        lblMsg.Text = "Either username or password is incorrect..";
                    }
                }
                else
                {
                    lblMsg.Text = "Either username or password is incorrect..";

                }
            }

         
            catch (Exception ex)
            {
                lblMsg.Text = "Something went wrong...Daatabase connection problem... " + ex.ToString();
            }

        }

    }

}