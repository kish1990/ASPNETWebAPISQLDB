﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PatientAdmissionASPNETWebAPIApp.CommonObj
{
    public class Users
    {
         
        private int nUserID = 0;
        private string strUserName = string.Empty;
        private string strPassword = string.Empty;
      
        public int UserID
        {
            get { return this.nUserID; }
            set { this.nUserID = value; }
        }
      
        public string UserName
        {
            get { return this.strUserName; }
            set { this.strUserName = value; }
        }
        public string Password
        {
            get { return this.strPassword; }
            set { this.strPassword = value; }
        }
   
    }
}