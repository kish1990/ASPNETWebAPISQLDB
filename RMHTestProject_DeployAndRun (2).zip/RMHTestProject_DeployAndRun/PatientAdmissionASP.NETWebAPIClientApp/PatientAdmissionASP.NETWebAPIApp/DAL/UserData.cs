﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
namespace PatientAdmissionASPNETWebAPIApp.DAL
{
    public class UserData
    {
        string strConn = System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection1"].ConnectionString;

        public List<CommonObj.Users> GetUser(string strUserName, string strPassword)
        {
            //Previously To test login harcoded instead of using Databse storage
            //but now if user enters admin it logs in by verifying credentials here
            //else if username and passowrd entered "sp" and "sp", then it it finds in DataBase using storeproc
            if (strUserName.ToString() == "admin")
            {
                List<CommonObj.Users> objUsers = new List<CommonObj.Users>();
                CommonObj.Users objUser = new CommonObj.Users();
                objUser.UserID = 1;
                objUser.Password = "admin";
                objUser.UserName = "admin";
                objUsers.Add(objUser);
                return objUsers;
            }
            else
            { //else if username and passowrd entered are "sp" and "sp", then it finds in DataBase using storeproc

                SqlConnection myConnection = new SqlConnection(strConn);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "GetUserWithUserName";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@UserName", SqlDbType.VarChar).Value = strUserName;
                cmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = strPassword;

                SqlDataReader rdr = null;
                cmd.Connection = myConnection;
                try
                {

                    if (myConnection.State == ConnectionState.Closed)
                    {
                        myConnection.Open();
                    }

                    List<CommonObj.Users> objUsers = new List<CommonObj.Users>();


                    rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        CommonObj.Users objUser = new CommonObj.Users();
                        this.GetUsers(rdr, objUser);
                        objUsers.Add(objUser);
                    }
                    return objUsers;
                }
                catch (SqlException sqlex)
                {
                    //objLogfile.ErrorLog(exception.Message, exception.GetBaseException().ToString());

                    throw sqlex;
                }
                finally
                {
                    rdr.Close();
                    myConnection.Dispose();
                }
            }
      
        }
        protected void GetUsers(IDataReader rdr, CommonObj.Users objUser)
        {
            objUser.UserID = rdr["UserID"] is DBNull ? 0 : (int)rdr["UserID"];
            objUser.UserName = rdr["UserName"] is DBNull ? string.Empty : rdr["UserName"] as string;
            objUser.Password = rdr["Password"] is DBNull ? string.Empty : rdr["Password"] as string;
            

        }

    }
}