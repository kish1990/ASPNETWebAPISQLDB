﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Diagnostics;
// Add a reference to the System.Management dll.
using System.Management;
using System.Xml;
using System.IO;
using System.Net;
using System.Web;
using System.Runtime.Serialization;
using System.Xml.Xsl;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Configuration;
using System.Data;

namespace PatientAdmissionASP.NETWebAPIApp
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["UserName"] == null || Session["UserName"] == "")
            {
                Server.Transfer("default.aspx");
            }
            else
            {
                try
                {

                    //Console.ReadLine();
                    string strURL = System.Configuration.ConfigurationManager.AppSettings["URLWebAPI"]; //"http://localhost:53287/api/PatientInfo";
                    var json1 = "";
                    string strRootElement = "";
                    XmlDocument xmlDoc1 = new XmlDocument();
                    JObject UpdateRootNodeToJjson1;
                    using (WebClient wc = new WebClient())
                    {
                        wc.Headers.Add("accept", "text/html");

                        // Set the header so it knows we are sending JSON
                        wc.Headers[HttpRequestHeader.ContentType] = "text/html";

                        json1 = wc.DownloadString(strURL);
                        //convet json into series of objects
                        JArray a = JArray.Parse(json1);
                        UpdateRootNodeToJjson1 = new JObject(
                                           new JProperty("PatientInfo", a)
                                           );

                    }

                    Newtonsoft.Json.Linq.JObject jObject1 = Newtonsoft.Json.Linq.JObject.Parse(UpdateRootNodeToJjson1.ToString());
                    json1 = UpdateRootNodeToJjson1.ToString(); //Assign json object string back now with UpdateRootNode


                    // instead of WriteLine, 2 or 3 lines of code here using WebClient to download the file
                    ////////Writes Json string as json file txt.json
                    //File.WriteAllText(Application.StartupPath + "../../../printcustomerorder.json", json1);
                    ////////

                    foreach (var itemval in jObject1)
                    {
                        strRootElement = itemval.Key;
                    }

                    xmlDoc1 = (XmlDocument)JsonConvert.DeserializeXmlNode(json1, strRootElement);

                    //////////Saves and reads xml Doc object to and from xml file on specfied path
                    /////////////xmlDoc1.Save(Application.StartupPath + "../../../CustomerOrderDocInfo1.xml");

                    ////Saves and reads xml Doc object to and from xml file on specfied path
                    xmlDoc1.Save(Server.MapPath("\\XML\\PatientInfo.XML"));

                    ///////////////////ds.ReadXml(Application.StartupPath + "../../../CustomerOrderDocInfo1.xml");
                    //////////////////end save and read xm doc 

                    /////////////sample read xml file and select it from nodelist to set (further DataGrid.Source=Ds.Tables[0], then works, otherwise it gives error for a node
                    ////////xmlDoc1.Load(Application.StartupPath + "../../../CustomerOrderDocInfo1.xml");
                    ////////XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes("/Table/Product");
                    /////////////////////////////////////end sample
                    ////looping in case if required to display single field data by extracting single data node
                    XmlNode root = xmlDoc1.FirstChild;
                    if (root.HasChildNodes)
                    {
                        for (int i = 0; i < root.ChildNodes.Count; i++)
                        {
                            for (int j = 0; j < root.ChildNodes[i].ChildNodes.Count; j++)
                            {

                            }
                        }
                        //Using dynamic keyword with JsonConvert.DeserializeObject, here you need to import Newtonsoft.Json  


                        //Using DataTable, here you have to import System.Data  

                        DataSet ds = new DataSet();

                        ds.ReadXml(Server.MapPath("\\XML\\PatientInfo.XML"));

                        GridView1.DataSource = ds;

                        GridView1.DataBind();


                    }
                }
                catch (Exception ex)
                {
                    lblMsg.Text= "Please confirm the required WebAPI service is currently running or please correct the Value= http://localhost:yourcurrentportnumber/api/PatienInfo  of running WebAPI in the web.config in the AppSettingd-> Key=URLWebAPI";
                }
            }
           

        }

        protected void btnAddNew1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PatientAdmission.aspx");
        }

     

        

       
 
        }
    }
